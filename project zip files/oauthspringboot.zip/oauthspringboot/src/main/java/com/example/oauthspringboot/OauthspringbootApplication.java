package com.example.oauthspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OauthspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OauthspringbootApplication.class, args);
	}

}
