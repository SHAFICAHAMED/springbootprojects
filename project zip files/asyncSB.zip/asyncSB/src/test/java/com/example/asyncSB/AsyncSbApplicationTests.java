package com.example.asyncSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsyncSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
