package com.example.Sentiment.Analysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SentimentAnalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
