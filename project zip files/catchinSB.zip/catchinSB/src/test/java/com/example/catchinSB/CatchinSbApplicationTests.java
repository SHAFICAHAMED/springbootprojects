package com.example.catchinSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatchinSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
