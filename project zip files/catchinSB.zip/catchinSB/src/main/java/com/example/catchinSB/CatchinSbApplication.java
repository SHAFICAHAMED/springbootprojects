package com.example.catchinSB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatchinSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatchinSbApplication.class, args);
	}

}
