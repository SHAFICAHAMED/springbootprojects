package com.example.employeeemanger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeemangerApplicationTests {

	@Test
	void contextLoads() {
	}

}
