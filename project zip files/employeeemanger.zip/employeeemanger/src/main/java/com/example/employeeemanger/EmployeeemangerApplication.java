package com.example.employeeemanger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeemangerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeemangerApplication.class, args);
	}

}
