package com.example.cafemangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafemangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
