package com.example.SalesRecord;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesRecordApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesRecordApplication.class, args);
	}

}
