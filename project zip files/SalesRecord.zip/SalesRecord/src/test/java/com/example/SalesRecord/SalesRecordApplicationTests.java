package com.example.SalesRecord;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
