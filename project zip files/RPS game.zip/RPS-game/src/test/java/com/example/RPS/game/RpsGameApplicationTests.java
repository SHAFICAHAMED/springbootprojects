package com.example.RPS.game;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RpsGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
