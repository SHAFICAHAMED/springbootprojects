package com.example.OCR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcrApplicationTests {

	@Test
	void contextLoads() {
	}

}
